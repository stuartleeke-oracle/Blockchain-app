/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your about ViewModel code goes here
 */
define(['ojs/ojcore','knockout','jquery','appController','ojs/ojknockout','ojs/ojswitch','ojs/ojgauge','ojs/ojinputtext','ojs/ojlabel'],
  function (oj, ko, $, app) {

    function SubmitReviewViewModel() {
      var self = this;
      // Below are a set of the ViewModel methods invoked by the oj-module component.
      // Please reference the oj-module jsDoc for additional information.

      /**
       * Optional ViewModel method invoked after the View is inserted into the
       * document DOM.  The application can put logic that requires the DOM being
       * attached here. 
       * This method might be called multiple times - after the View is created 
       * and inserted into the DOM and after the View is reconnected 
       * after being disconnected.
       */
      self.connected = function () {
        // Implement if needed
      
      
        self.isDoctorChecked = ko.observable();
        self.ratingDoctor = ko.observable(0);
        self.valueDoctor = ko.observable("");


        self.isDoctorCheckedRole = ko.observable();
        self.ratingDoctorRole = ko.observable(0);
        self.valueDoctorRole = ko.observable("");


        self.isCommentsChecked = ko.observable();
        self.valueComments = ko.observable("");

        self.isHireChecked = ko.observable();


  
        self.onValueChangedDoctor = function (data) {
       
          if (data.detail.value === true) {
            $(':focus').blur();
            $("#text-input-Doctor")[0].disabled = true;
            self.valueDoctor("");
          }
          else {
            $("#text-input-Doctor")[0].disabled = false;
         //   console.log("Not Hello", self.valueDoctor());
          }
        }


        self.onValueChangedDoctorRole = function (data) {
       
          if (data.detail.value === true) {
            $(':focus').blur();
            $("#text-input-DoctorRole")[0].disabled = true;
            self.valueDoctorRole("");
          }
          else {
            $("#text-input-DoctorRole")[0].disabled = false;
           // console.log("Not Hello", self.valueDoctor());
          }
        }

        self.onValueChangedComments = function (data) {
    
          if (data.detail.value === true) {
            $(':focus').blur();
            $("#text-input-Comments")[0].disabled = true;
            self.valueComments("");
          }
          else {
            $("#text-input-Comments")[0].disabled = false;
           // console.log("Not Hello", self.valueDoctor());
          }
        }

        self.submitClick = function (data) {
          console.log("Confirm", data);
          app.goTodrReview();
        }


      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function () {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function () {
        // Implement if needed
      };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new SubmitReviewViewModel();
  }
);
