/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your about ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery', 'appController', 'ojs/ojknockout', 'ojs/ojselectcombobox', 'ojs/ojinputtext', 'ojs/ojlabel'],
  function (oj, ko, $, app) {

    function LandingPageViewModel() {
      var self = this;

      console.log("In Landing Page View Model");


      self.navList = ko.observableArray([]);


      self.connected = function () {
        // Implement if needed

        console.log("In Connected");

        self.val = ko.observableArray(["Select"]);

        self.val("Select");

        self.jobHistory = ko.observable(2);
        self.hospitalReview = ko.observable(3);
        self.listLocum = ko.observable(1);
        self.drReview = ko.observable(4);
        self.drSelect = ko.observable(3);


        if (app.userType() === 'Locum') {

          self.navList.push({ name: 'Job History', color: "black;", backgroundColor: "white", imageSrc: "css/images/job_history.png", notification: self.jobHistory() },
            { name: 'Hospital Review', color: "black;", backgroundColor: "white", imageSrc: "css/images/hospital.png", notification: self.hospitalReview() },
            { name: 'Log Out', color: "black;", backgroundColor: "white", imageSrc: "css/images/logout.png" });


        }
        else if (app.userType() === 'SrDoctor') {
          self.navList.push(
            { name: 'Select Locum', color: "black;", backgroundColor: "white", imageSrc: "css/images/job_history.png", notification: self.drSelect() },
            { name: 'List of Locums', color: "black;", backgroundColor: "white", imageSrc: "css/images/list.png", notification: self.listLocum() },
            { name: 'Dr Review', color: "black;", backgroundColor: "white", imageSrc: "css/images/dr.png", notification: self.drReview() },
            { name: 'Log Out', color: "black;", backgroundColor: "white", imageSrc: "css/images/logout.png" });

        }





        self.userName = ko.observable("");
        self.password = ko.observable("");

        self.divVisible = ko.observable(false);

        self.valueChange = function (event) {

          console.log("Value Change", event);

          if (self.val() === "SrDoctor" || self.val() === "Locum") {
            if (self.val() === "Locum") {
              self.divVisible(true);
            }
            else if (self.val() === "SrDoctor") {
              self.divVisible(true);
            }

          }
          else {
            self.divVisible(false);
          }
        };


        self.submitClick = function (event) {
          console.log("In Submit", event);
          if (event.name === "Job History") {

            app.goTodashboardLocum();
          }
          else if (event.name === "Hospital Review") {

            app.goTohospitalReview();
          }
          else if (event.name === "Select Locum") {

            app.goTolocumSelect();
          }
          else if (event.name === "List of Locums") {

            app.goTodashboardHead();

          }
          else if (event.name === "Dr Review") {

            app.goTodrReview();
          }
          else if (event.name === "Log Out") {

            app.goTologin();
          }

        };





      };

      self.disconnected = function () {
        self.navList([]);
      };

      self.transitionCompleted = function () {

      };
    }

    return new LandingPageViewModel();
  }
);
