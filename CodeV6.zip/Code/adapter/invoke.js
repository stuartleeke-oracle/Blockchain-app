const http = require('http');
const rp = require('request-promise');
const settings = require('../settings/settings');
const async = require('async');

const host = '129.213.38.51';
var sbiport1 = parseInt(settings.sbibcport1);
var tspport1 = parseInt(settings.tspbcport1);
var sbiport2 = parseInt(settings.sbibcport2);
var tspport2 = parseInt(settings.tspbcport2);
var sbiporttoggle = true;
var tspporttoggle = true;

exports.postData = function (dataArray) {  

    return new Promise(function (resolve, reject) {
        var errorcount = 0;
        var successcount = 0;
        
        async.eachLimit(dataArray, 10, function (data, callback) {
            var port = null;
            if(sbiporttoggle) {
                port = sbiport2;
                sbiporttoggle = false;
            }
            else {
                port = sbiport1;
                sbiporttoggle = true;
            }

            var options = {
                method: 'POST',
                uri: 'http://' + settings.sbiblockchainhost + ':' + port + settings.blockchainpath, //'http://129.213.38.51:5002/bcsgw/rest/v1/transaction/invocation',
                // headers: {
                //     'User-Agent': 'Request-Promise'
                // },
                body: data,
                //proxy: 'http://www-proxy-idc.in.oracle.com:80',
                json: true
            };
    
            rp(options)
            .then(function (parsedResponse) {
                console.log(data.method + " -- " + JSON.stringify(parsedResponse));
                successcount++;
                callback();
            })
            .catch(function (err) {
                console.log(err);
                errorcount++;
                callback();
            });
        }, function (err) {
            if(err) {
                console.log(err);
                // resolve('error');
            } else {
                console.log('posted');
            }
            var data = {'total' : dataArray.length, 'success' : successcount, 'error': errorcount};
            resolve(data);
        });
    });
}


exports.postTSPData = function (dataArray) {  

    return new Promise(function (resolve, reject) {
        var errorcount = 0;
        var successcount = 0;
        
        async.eachLimit(dataArray, 10, function (data, callback) {
            var port = null;
            if(tspporttoggle) {
                port = tspport1;
                tspporttoggle = false;
            }
            else {
                port = tspport2;
                tspporttoggle = true;
            }

            var options = {
                method: 'POST',
                uri: 'http://' + settings.tspblockchainhost + ':' + port + settings.blockchainpath, //'http://129.213.38.51:5002/bcsgw/rest/v1/transaction/invocation',
                // headers: {
                //     'User-Agent': 'Request-Promise'
                // },
                body: data,
                //proxy: 'http://www-proxy-idc.in.oracle.com:80',
                json: true
            };
    
            rp(options)
            .then(function (parsedResponse) {
                console.log(data.method + " -- " + JSON.stringify(parsedResponse));
                successcount++;
                callback();
            })
            .catch(function (err) {
                console.log(err);
                errorcount++;
                callback();
            });
        }, function (err) {
            if(err) {
                console.log(err);
                // resolve('error');
            } else {
                console.log('posted');
            }
            var data = {'total' : dataArray.length, 'success' : successcount, 'error': errorcount};
            resolve(data);
        });
    });
}
