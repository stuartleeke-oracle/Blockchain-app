
define(['ojs/ojcore', 'knockout', 'jquery', 'appController', 'ojs/ojvalidation-datetime'],
  function (oj, ko, $, app) {


    function LocumSelectViewModel() {
      var self = this;

      self.connected = function () {
        // Implement if needed
        //    console.log("In Connected of Head");

        self.dataHead = ko.observableArray();

        var dateOptions = { formatType: 'datetime', dateFormat: 'medium' };
        var dateConverterFactory = oj.Validation.converterFactory("datetime");
        self.dateConverter = dateConverterFactory.createConverter(dateOptions);

        let data = [];


        app.drAssignment("");
        app.drShift("");

        console.log(self);

        let obj = {};

        genericMethods.genericQueryAjax(obj, "getAssignmentsByStatus?status=DownSelect", "GET").then((data1) => {

          console.log("Data", data1);


          for (var i = 0; i < data1.length; i++) {


            let assignmentId = data1[i].id;
        

            let count = i;

            let assignmentObj = data1[i];

            if (typeof assignmentId !== "undefined" ) {

              console.log
              //   var p1 = genericMethods.genericAjax(obj,"Assignment/"+assignmentId,"GET");

              for (var j = 0; j < data1[i].downSelectedIds.length; j++) {

                console.log("In For Loop");

                console.log(data1[i]);
                let locumDrId = data1[i].downSelectedIds[j];
                console.log(locumDrId);
                let count1 = j;

                genericMethods.genericQueryAjax(obj, "retrieveLocumDoctorById?locumDoctorId=" + locumDrId, "GET").then( (values) => {
                  console.log("Value " + count + " " + count1);
                  console.log(values);
                  console.log(data1[i]);
                  console.log(assignmentObj);
  
                  let dateTime = new Date(assignmentObj.startDateTime);
                  let date = dateTime.toISOString().slice(0, 10);
                  let lengthDrRecord = values.length;
  
                  self.dataHead.push({
                    id: count,
                    DrName: "Dr. " + values[0].firstName + " " + values[0].lastName,
                    Hospital: assignmentObj.hospitalName,
                    StartDate: date.toString(),
                    EndDate: assignmentObj.endDateTime,
                    Details: assignmentObj.assignmentDetails,
                    Status: assignmentObj.status,
                    AssignmentId: assignmentObj.id,
                    AssignmentObj: assignmentObj,
                    drObj: values[lengthDrRecord - 1]
                  });
                  // { id: "1", DrName: "Dr Roberts", Hospital: "Blackpool University Hospital", Date: "14/06/18", Shift: "12hr shift in A&E", Status: "Currently Active" }
                });;

              }


            }
          }


        }).catch((error) => {
          console.log("Error", error);
        });


  
        self.detailsClick = function (event, data) {
          console.log("Details Click", data.data);

          app.assignmentDoctorObject(data.data);

          console.log("Details assignmentDoctorObject", app.assignmentDoctorObject());

          app.goTolocumDrDetails(data.data);

        }

    

      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function () {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function () {
        // Implement if needed
        //   console.log("Router Obj in Dashboard",app.router.stateId());
      };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new LocumSelectViewModel();
  }
);
