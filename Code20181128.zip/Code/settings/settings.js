exports.blockchainport = 5003;
exports.blockchainpath = '/bcsgw/rest/v1/transaction/invocation';
exports.bcquerypath = '/bcsgw/rest/v1/transaction/query';