
define(['ojs/ojcore', 'knockout', 'jquery', 'appController', 'ojs/ojvalidation-datetime'],
  function (oj, ko, $, app) {


    function DashboardViewModel() {
      var self = this;

      self.connected = function () {
        // Implement if needed
        //    console.log("In Connected of Head");

        self.dataHead = ko.observableArray();
        self.userName = app.activeUserName;

        var dateOptions = { formatType: 'datetime', dateFormat: 'medium' };
        var dateConverterFactory = oj.Validation.converterFactory("datetime");
        self.dateConverter = dateConverterFactory.createConverter(dateOptions);

        let data = [];


        app.drAssignment("");
        app.drShift("");

        console.log(self);

        let obj = {};

        let assignmentMap = new Map();



        genericMethods.genericQueryAjax(obj, "getAssignmentsByStatus?status=Accepted", "GET").then((data1) => {

          console.log("Data", data1);

          let k = 0;


          for (var i = 0; i < data1.length; i++) {
            console.log("In For Loop1");

            let assignmentId = data1[i].id;


            let count = i;

            let assignmentObj = data1[i];

            if (typeof assignmentId !== "undefined") {

              console.log
              //   var p1 = genericMethods.genericAjax(obj,"Assignment/"+assignmentId,"GET");

              for (var j = 0; j < data1[i].downSelectedIds.length; j++) {

                console.log("In For Loop2");

                console.log(data1[i]);
                let locumDrId = data1[i].downSelectedIds[j];
                console.log(locumDrId);
                let count1 = k;



                genericMethods.genericQueryAjax(obj, "retrieveLocumDoctorById?locumDoctorId=" + locumDrId, "GET").then((values) => {
                  console.log("Value " + count + " " + count1);
                  console.log(values);
                  console.log(assignmentObj);

                  let dateTime = new Date(assignmentObj.startDateTime);
                  let date = dateTime.toISOString().slice(0, 10);
                  let lengthDrRecord = values.length;

                  let index = self.dataHead.push({
                    id: count,
                    DrName: "Dr. " + values[0].firstName + " " + values[0].lastName,
                    Hospital: assignmentObj.hospitalName,
                    StartDate: date.toString(),
                    EndDate: assignmentObj.endDateTime,
                    Details: assignmentObj.assignmentDetails,
                    Status: assignmentObj.status,
                    AssignmentId: assignmentObj.id,
                    AssignmentObj: assignmentObj,
                    drObj: values[lengthDrRecord - 1],
                    identity: ko.observable(true),
                    timeSheet: ko.observable(false),
                    timesheetObj: null

                  });

                  console.log("DataHead Length ", index);

                  assignmentMap.set(assignmentObj.id + values[lengthDrRecord - 1].id, index - 1);



                  getOtherData(count1, assignmentObj.id);


                  // { id: "1", DrName: "Dr Roberts", Hospital: "Blackpool University Hospital", Date: "14/06/18", Shift: "12hr shift in A&E", Status: "Currently Active" }
                });;

                k++;

              }


            }
          }

          genericMethods.genericAjax(obj, "identityChecked", "GET").then((values) => {

            console.log("Identity Check ", values);

            for (let i = 0; i < values.length; i++) {

              let index = assignmentMap.get(values[i].assignmentId + values[i].doctorId);

              if (typeof index !== "undefined") {

                self.dataHead()[index]['identity'](false);

              }
              else {
                self.dataHead()[index]['identity'](true);
              }

            }

            console.log("Data Head", self.dataHead());




          }).catch((error) => {
            console.log("Error in Identity", error);
          });


          console.log("Map ", assignmentMap);


        }).catch((error) => {
          console.log("Error", error);
        });


        function getOtherData(id, assignmentId) {

          console.log("In getOtherData", id, assignmentId);
          let obj = {};
          let dataHeadId = id;
          let assignId = assignmentId;


          genericMethods.genericQueryAjax(obj, "getTimesheetByAssignmentId?assignmentId=" + assignId, "GET").then((values) => {

            console.log("TimeSheet " + dataHeadId, values);
            if(values.length > 0 ){
            let index = assignmentMap.get(values[0].assignmentId + values[0].locumDoctorId);

              self.dataHead()[index]['timeSheet'](true);
              self.dataHead()[index]['timesheetObj'] = values;

            }


          }).catch((error) => {
            console.log("Error in TimeSheet", error);
          });



        }



        self.detailsClick = function (event, data) {
          console.log("Details Click", data.data);

          app.assignmentDoctorObject(data.data);

          console.log("Details assignmentDoctorObject", app.assignmentDoctorObject());

          app.goToReVerifyIdentity();

        }

        self.timeSheetClick = function (event, data) {
          console.log("Time Sheet Click", data.data);

          app.assignmentDoctorObject(data.data);

          console.log("Details assignmentDoctorObject", app.assignmentDoctorObject());

          app.goTotimesheet();

        }



      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function () {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function () {
        // Implement if needed
        //   console.log("Router Obj in Dashboard",app.router.stateId());
      };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new DashboardViewModel();
  }
);
