/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your about ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery','appController', 'ojs/ojknockout', 'ojs/ojswitch', 'ojs/ojaccordion', 'ojs/ojvalidation-datetime'],
 function(oj, ko, $,app) {

    function TimeSheetViewModel() {
      var self = this;
      // Below are a set of the ViewModel methods invoked by the oj-module component.
      // Please reference the oj-module jsDoc for additional information.

      /**
       * Optional ViewModel method invoked after the View is inserted into the
       * document DOM.  The application can put logic that requires the DOM being
       * attached here.
       * This method might be called multiple times - after the View is created
       * and inserted into the DOM and after the View is reconnected
       * after being disconnected.
       */


      var dateOptions = { formatType: 'datetime', dateFormat: 'medium' };
      var dateConverterFactory = oj.Validation.converterFactory("datetime");
      self.dateConverter = dateConverterFactory.createConverter(dateOptions);

      self.connected = function() {

       var dataObj = app.assignmentDoctorObject();

       self.assingmentDetails = ko.observable(dataObj.Details);
       self.hospital = ko.observable(dataObj.Hospital);
       self.status = ko.observable(dataObj.Status);

       var startDT =  self.dateConverter.format(dataObj.AssignmentObj.startDateTime) ;
       var endDT =  self.dateConverter.format(dataObj.AssignmentObj.endDateTime)  ;

       self.checkFunc = function (data) {

        console.log("In checkFunc",  data);

       }

       self.assingmentPeiord = ko.observable( startDT + " to " + endDT);

        console.log("Data from Previous Page", dataObj);

        // Implement if needed

        self.drName = ko.observable(dataObj.drObj.firstName + " " + dataObj.drObj.lastName);
        self.drId = ko.observable(dataObj.drObj.id);

        let count = 0;

        const timeSheet = dataObj.timesheetObj.map(obj =>{
            var rObj = {};

            let startDT =  self.dateConverter.format(obj.checkInTime) ;
            let endDT =  self.dateConverter.format(obj.checkOutTime)  ;

            rObj['count'] =  count ;
            rObj['id'] =  obj.id ;
            rObj['ChekInTime'] =  startDT ;
            rObj['ChekOutTime'] =  endDT ;
            rObj['status'] = ko.observable(obj.status) ;

            count++;
            return rObj;
        }
        );

        self.timeSheetArray = ko.observableArray(timeSheet);



        self.confirmClick = function(event,data){
          console.log("Confirm",data.data);


          var obj = {};

          obj["$class"] = "org.uk.nhs.approveTimesheet";
          obj["timesheetId"] = data.data.id;
          obj["approvedById"] = "SD002";
          obj["status"] = "Approved";

          console.log("Object", obj);
          sendApproveReject(obj,data.data.count);

         // app.goTodashboardHead();

       }

       self.rejectClick = function(event,data){
        console.log("Reject",data.data);


        var obj = {};

        obj["$class"] = "org.uk.nhs.approveTimesheet";
        obj["timesheetId"] = data.data.id;
        obj["approvedById"] = "SD002";
        obj["status"] = "Rejected";

        console.log("Object", obj);
        sendApproveReject(obj,data.data.count);

       // app.goTodashboardHead();

     }


     self.backClick = function(event,data){
        console.log("Back",data.data);
        app.goToTimesheetList();

     }


       function sendApproveReject(obj,count) {

        let index = count;
        let changingStatus = obj["status"];
              genericMethods.genericAjax(obj,"approveTimesheet","POST").then((data1) => {

            console.log("Success in approveTimesheet Call", data1);

            self.timeSheetArray()[index]['status'](changingStatus);


          }).catch((err) => {

            console.log("Error", err);

          });
       }


      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function() {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function() {
        // Implement if needed
      };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new TimeSheetViewModel();
  }
);
