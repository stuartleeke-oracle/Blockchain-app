var express = require('express');
var router = express.Router();

const rp = require('request-promise');

var url = require('url');

var fs = require('fs');

const http = require('http');

const axios = require('axios');

//var json2xls = require('json2xls');

const json2csv = require('json2csv').parse;

const TRUU_API_CONNECTION = axios.create({
  baseURL: 'http://bth.eastus.cloudapp.azure.com/',
  timeout: 9000,
  header: {
    'Content-Type': 'application/json',
    'Authorization': 'Basic dHJ1dWVuZHBvaW50OlRXWlJMMXNUSTN2SXlqNWpRM2k2UG1XRXhlUTlLMGlC'
  }
});


/* GET home page. */
router.get('/', function (req, res, next) {
  //res.render('index', { title: 'Express' });
  res.sendFile('../public/index.html');
});

router.get('/truuDoctorDetails', function (req, res, next) {
  try {
    console.log('BOOPED SERVER');
    console.log("REQUEST:", req.query.id + ",  " +req.query.proof_name );

    const url = 'http://bth.eastus.cloudapp.azure.com/proof/retrieve/' + req.query.id + '/' + req.query.proof_name;
    console.log("QUERY URL: ", url);
    var config = {
      auth: {
        username: 'truuendpoint',
        password: 'TWZRL1sTI3vIyj5jQ3i6PmWExeQ9K0iB'
      }
    }
    //TRUU_API_CONNECTION.get('proof/retrieve/QRRgyMNaW4rnhoo2eSQ7FA/Primary_Medical_Qualification').then(function(result) {
    try {
      axios.get(url, config).then(function(result){
        if(result){
          if(result.status === 200){
            //res.send(result.data)
            console.log("CALL RESULT: ", result.data);
            var resultJSON = JSON.stringify(result.data);
            res.send(result.data);
          } else {
            console.log("Not 200: ", result.status);
          }
        }
      }).catch(function(err){
        res.send(err)
        console.log("Error: ", error);
      })
    } catch(err) {
      console.log("ERROR occurred while getting Doctor details: ", err);
      res.send({error: err.message});
    }
  } catch(err){
    console.log("ERROR occurred while getting Doctor details: ", err);
  }
});

router.post('/genericAjax', function (req, res, next) {

  console.log("in Generic Ajax");

  var options = {
    method: req.body.method,
    uri: req.body.url,
    headers: {

      'Content-Type':'application/json'
    },

    json: true
  };

  if(req.body.method === 'POST'){

    options.body= req.body.data;

  }

  rp(options)
    .then(function (parsedResponse) {
      res.writeHead(200, {'Content-Type': 'application/json'});
      res.end(JSON.stringify(parsedResponse));
    })
    .catch(function (err) {
      console.log(err);
      res.end(JSON.stringify(err));
    });
});

router.get('/genericAjax1', function (req, res, next) {

  console.log("in Generic Ajax1");

  // var options = {
  //   method: req.body.method,
  //   uri: req.body.url,
  //   headers: {

  //     'Content-Type':'application/json'
  //   },
  //   body: req.body.data

  //   // json: true
  // };

  // const postData = querystring.stringify({
  //   'msg': 'Hello World!'
  // });

  const options = {
    hostname: 'http://51.140.13.206:31090',
    port: 80,
    path: '/api/selectCandidate',
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };

  http.get('http://51.140.13.206:31090/api/createNewAssignment', (resp) => {
    let data = '';

    // A chunk of data has been recieved.
    resp.on('data', (chunk) => {
      data += chunk;
      console.log("Data",chunk);
    });

    // The whole response has been received. Print out the result.
    resp.on('end', () => {
      console.log(JSON.parse(data).explanation);
      res.end(data);
    });

  }).on("error", (err) => {
    console.log("Error: " + err.message);
  });



});



router.post('/login', function (req, res, next) {

  console.log("in login");

  console.log(req.body);

  var usersObj;

  fs.readFile('./settings/users.json', function (err, data) {

    usersObj = JSON.parse(data.toString()).users ;

    console.log(usersObj);

    var result = usersObj.find(user => { if(user.name === req.body.user && user.password === req.body.password) {return 1;}  else { return 0;} } );

    var responeObj = {};

    if(typeof(result) !== "undefined") {
      console.log("Result", result);
      responeObj.auth = 1;
      responeObj.role = result.role;
    }
    else{
      console.log("Result undefined");
      result = {};
      responeObj.auth = 0;
    }

    res.writeHead(200, {'Content-Type': 'application/json'});

    res.write(JSON.stringify(responeObj));
    res.end();

  });

  //res.end('Hello');

});


module.exports = router;
