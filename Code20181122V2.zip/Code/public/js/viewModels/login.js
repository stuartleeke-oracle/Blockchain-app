/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your about ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery','appController', 'ojs/ojknockout', 'ojs/ojselectcombobox', 'ojs/ojinputtext', 'ojs/ojlabel'],
 function(oj, ko, $, app) {

    function LoginViewModel() {
      var self = this;
      // Below are a set of the ViewModel methods invoked by the oj-module component.
      // Please reference the oj-module jsDoc for additional information.





      console.log("In Login View Model");



      /**
       * Optional ViewModel method invoked after the View is inserted into the
       * document DOM.  The application can put logic that requires the DOM being
       * attached here.
       * This method might be called multiple times - after the View is created
       * and inserted into the DOM and after the View is reconnected
       * after being disconnected.
       */

      self.connected = function() {
        // Implement if needed

        console.log("In Connected");

        self.val = ko.observableArray(["Select"]);

        self.val("Select");

        self.userName = ko.observable("");
        self.password = ko.observable("");
        self.name = ko.observable("Welcome");

        self.divVisible = ko.observable(false);

        self.valueChange = function (event) {

          console.log("Value Change", event);

          if(self.val() === "SrDoctor" || self.val() === "Locum" ){
              if(self.val() === "Locum"){
                self.divVisible(true);
                self.name("Login");
              }
              else if(self.val() === "SrDoctor"){
                self.divVisible(true);
                self.name("Login");
              }

          }
          else {
            self.divVisible(false);
            self.name("Welcome");
          }
        };


        self.submitClick = function () {
          console.log("In Submit");
          if(self.val() === "Locum"){

            if(self.userName() === "Roberts" &&  self.password() === "welcome1"){
              app.userType('Locum');
              app.activeUserName("Roberts");
              app.goToLandingPage();
          //    app.goTodashboardLocum();
            }
            else {
              alert("Please verify User Name and Password");
            }



          }
          else if(self.val() === "SrDoctor"){
            if(self.userName() === "Jacob" &&  self.password() === "welcome1"){
              app.userType('SrDoctor');
              app.activeUserName("Jacob");
              app.goToLandingPage();
        //      app.goTodashboardHead();
            }
            else {
              alert("Please verify User Name and Password");
            }
          }
        };

        self.cancelClick = function () {
          self.userName("");
          self.password("");
          self.val("Select");
          self.name("Welcome");
          self.divVisible(false);
        };



      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function() {
        // Implement if needed
    //    console.log("In Disconnected");
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function() {
        // Implement if needed
      //  console.log("In Transition Completed");



      //  console.log("Router Obj in Login",app.router.stateId());


      };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new LoginViewModel();
  }
);
