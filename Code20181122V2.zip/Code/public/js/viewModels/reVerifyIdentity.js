/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your about ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery','appController', 'ojs/ojknockout', 'ojs/ojswitch', 'ojs/ojaccordion', 'ojs/ojvalidation-datetime'],
 function(oj, ko, $,app) {

    function ReVerifyIdentityViewModel() {
      var self = this;
      // Below are a set of the ViewModel methods invoked by the oj-module component.
      // Please reference the oj-module jsDoc for additional information.

      /**
       * Optional ViewModel method invoked after the View is inserted into the
       * document DOM.  The application can put logic that requires the DOM being
       * attached here.
       * This method might be called multiple times - after the View is created
       * and inserted into the DOM and after the View is reconnected
       * after being disconnected.
       */


      var dateOptions = { formatType: 'datetime', dateFormat: 'medium' };
      var dateConverterFactory = oj.Validation.converterFactory("datetime");
      self.dateConverter = dateConverterFactory.createConverter(dateOptions);

      self.connected = function() {
        console.log("CONNECTED PAGE DOCTOR DETAIL");

       var dataObj = app.assignmentDoctorObject();

       self.assingmentDetails = ko.observable(dataObj.Details);
       self.hospital = ko.observable(dataObj.Hospital);
       self.status = ko.observable(dataObj.Status);

       var startDT =  self.dateConverter.format(dataObj.AssignmentObj.startDateTime) ;
       var endDT =  self.dateConverter.format(dataObj.AssignmentObj.endDateTime)  ;

       self.checkFunc = function (data) {

        console.log("In checkFunc",  data);

       }

       self.assingmentPeiord = ko.observable( startDT + " to " + endDT);

        console.log("Data from Previous Page", dataObj);

        // Implement if needed

        self.isNameChecked = ko.observable();
        self.isShiftChecked = ko.observable();
        self.isQualificationChecked = ko.observable(false);

        self.requiredClaims = ko.observableArray(dataObj.AssignmentObj.requiredClaims);


        self.drName = ko.observable(dataObj.drObj.firstName + " " + dataObj.drObj.lastName);
        self.drId = ko.observable(dataObj.drObj.id);
        self.qualificationProof = ko.observableArray(dataObj.drObj.proof_Qualification);
        self.iDProof = ko.observableArray(dataObj.drObj.proof_ID);
        self.employemntProof = ko.observableArray(dataObj.drObj.proof_Employment);
        self.healthCheckProof = ko.observableArray(dataObj.drObj.proof_HealthCheck);

        //filter proof arrays for duplicates
        function filter(array){
          var filtered = [];
          array.forEach(function(nonUnique) {
            console.log("PROOF CONTENT: ", nonUnique);
            let found = filtered.find(function(unique){
              return(unique.claimName === nonUnique.claimName);
            });
            if(!found) {
              filtered.push(nonUnique);
            }
          });
          console.log("FILTERED: ", filtered);
          return filtered;
        }

        console.log("PROOF ARRAY: ", self.qualificationProof());
        self.qualificationProof = ko.observableArray(filter(self.qualificationProof()));
        self.iDProof = ko.observableArray(filter(self.iDProof()));
        self.employemntProof = ko.observableArray(filter(self.employemntProof()));
        self.healthCheckProof = ko.observableArray(filter(self.healthCheckProof()));

        self.TruudrName = ko.observable();
        self.TruudrId = ko.observable();
        self.TruuqualificationProof = ko.observableArray();
        self.TruuiDProof = ko.observableArray();
        self.TruuemployemntProof = ko.observableArray();
        self.TruuhealthCheckProof = ko.observableArray();

        console.log("Required Claims",self.requiredClaims());

        var claims = self.requiredClaims();
        console.log(claims.length);

        function addProofToArray(proofArray, truuProofArray, claim, newProof){
          proofArray().forEach(function(proof){
            if(proof.claimName === claim.claimName){
              var details = Object.keys(newProof.attributes.revealed_attrs).map(function(key, i){
                var value = Object.values(newProof.attributes.revealed_attrs)[i].raw;
                return {key, value};
              });
              var truuProofDetails = {
                claimName: claim.claimName,
                claimDetails: details
              }
              truuProofArray.push(truuProofDetails);
            }
          });
        }

        for(let i = 0; i < claims.length; i++) {
          genericMethods.truuAjax({id: dataObj.drObj.id, proof_name: claims[i].claimName},"","GET").then((data1) => {
            if(data1){
              addProofToArray(self.qualificationProof, self.TruuqualificationProof, claims[i], data1);
              addProofToArray(self.iDProof, self.TruuiDProof, claims[i], data1);
              addProofToArray(self.employemntProof, self.TruuemployemntProof, claims[i], data1);
              addProofToArray(self.healthCheckProof, self.TruuhealthCheckProof, claims[i], data1);
            }
            console.log("Success in Truu API Call", data1);
          }).catch((err) => {
            console.log("Error in Truu API call", err);
          });
        }




        self.confirmClick = function(data){
          console.log("Confirm",data);


          var obj = {};

          obj["$class"] = "org.uk.nhs.identityChecked";
          obj["assignmentId"] = dataObj.AssignmentObj.id;
          obj["doctorId"] = dataObj.drObj.id;
          obj["checkedById"] = "SD002";


          console.log("Object", obj);


          genericMethods.genericAjax(obj,"identityChecked","POST").then((data1) => {

            console.log("Success in Identity Check Call", data1);

            app.goTodashboardHead();
          }).catch((err) => {

            console.log("Error", err);

          });
         // app.goTodashboardHead();

       }


      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function() {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function() {
        // Implement if needed
      };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new ReVerifyIdentityViewModel();
  }
);
