/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your dashboard ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery','appController'],
 function(oj, ko, $,app) {
  
    function HospitalReviewViewModel() {
      var self = this;
      // Below are a set of the ViewModel methods invoked by the oj-module component.
      // Please reference the oj-module jsDoc for additional information.

      /**
       * Optional ViewModel method invoked after the View is inserted into the
       * document DOM.  The application can put logic that requires the DOM being
       * attached here. 
       * This method might be called multiple times - after the View is created 
       * and inserted into the DOM and after the View is reconnected 
       * after being disconnected.
       */
      self.connected = function() {
        // Implement if needed

        self.dataLocum = ko.observableArray();

        var data = [
          {id:"1", Hospital: "Blackpool University Hospital", Date: "14/06/18", Shift: "12hr shift in A&E", Status: "Currently Active"},
          {id:"2",Hospital: "Blackpool University Hospital", Date: "11/06/18", Shift: "12hr shift in A&E", Status: "Complete"},
          {id:"3",Hospital: "London University Hospital", Date: "9/06/18", Shift: "14hr shift in Fracture Clinic", Status: "Complete"},
          {id:"4", Hospital: "Birmingham Hospital", Date: "21/05/18", Shift: "12hr shift in A&E", Status: "Complete"},
          {id:"5", Hospital: "Birmingham Hospital", Date: "14/05/18", Shift: "12hr shift in A&E", Status: "Complete"}
        ];

        self.dataLocum(data);
     //   console.log("In Connected of Locum");

     self.reviewClick = function(event,data){
        console.log("Events Data",data);
   
      
        app.goToshiftFeedback();
      
     }
       

      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function() {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function() {
        // Implement if needed
     //   console.log("Router Obj in Dashboard",app.router.stateId());

     console.log("dataLocum",self.dataLocum());




      };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new HospitalReviewViewModel();
  }
);
