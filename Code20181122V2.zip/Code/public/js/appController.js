/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your application specific code will go here
 */
define(['ojs/ojcore', 'knockout', 'ojs/ojmodule-element-utils', 'ojs/ojmodule-element', 'ojs/ojrouter', 'ojs/ojknockout', 'ojs/ojarraytabledatasource',
  'ojs/ojoffcanvas'],
  function (oj, ko, moduleUtils) {
    function ControllerViewModel() {
      var self = this;

      // Media queries for repsonsive layouts
      var smQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY);
      self.smScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);
      var mdQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.MD_UP);
      self.mdScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(mdQuery);

      // Router setup
      self.router = oj.Router.rootInstance;
      self.router.configure({
        'dashboardLocum': { label: 'Dashboard' },
        'login': { label: 'Login', isDefault: true },
        'dashboardHead': { label: 'Dashboard' },
        'drReview': { label: 'Dr Review' },
        'submitReview': { label: 'Submit Review' },
        'drAssignment': { label: 'Assignment' },
        'shiftFeedback': { label: 'Shift Feedback' },
        'hospitalReview': { label: 'Hospital Feedback' },
        'LandingPage': { label: 'Landing Page' },
        'locumSelect': { label: 'Locum Select Page' },
        'locumDr': { label: 'Locum Doctor Details' },
        'reVerifyIdentity': { label: 'Re-Verify Identity' },
        'timesheet': { label: 'Time Sheet' }


      });


      oj.Router.defaults['urlAdapter'] = new oj.Router.urlParamAdapter();

      self.moduleConfig = ko.observable({ 'view': [], 'viewModel': null });

      self.drAssignment = ko.observable();
      self.drShift = ko.observable();
      self.activeUserName = ko.observable("Test");

      //submitReview Variables
      self.submitDrId = ko.observable();

      self.loadModule = function () {
        ko.computed(function () {
          //    console.log("In loadModule");
          var name = self.router.moduleConfig.name();
          var viewPath = 'views/' + name + '.html';
          var modelPath = 'viewModels/' + name;
          var masterPromise = Promise.all([
            moduleUtils.createView({ 'viewPath': viewPath }),
            moduleUtils.createViewModel({ 'viewModelPath': modelPath })
          ]);
          masterPromise.then(
            function (values) {
              self.moduleConfig({ 'view': values[0], 'viewModel': values[1] });
            },
            function (reason) { }
          );
        });
      };

      // Navigation setup
      navData = ko.observableArray();

      testCall = function (data) {


        console.log("Hello World!! ", data);

      }



      self.LocumNotifications = ko.observable(0);


      self.HeadNotifications = ko.observable(0);
      self.navDataSource = ko.computed(function () {

        console.log("In navDataSource", navData());

        return new oj.ArrayTableDataSource(navData(), { idAttribute: 'id' });
      });


      // Drawer
      // Close offcanvas on medium and larger screens
      self.mdScreen.subscribe(function () { oj.OffcanvasUtils.close(self.drawerParams); });
      self.drawerParams = {
        displayMode: 'push',
        selector: '#navDrawer',
        content: '#pageContent'
      };
      // Called by navigation drawer toggle button and after selection of nav drawer item
      self.home = function () {

        self.goToLandingPage();
        // return oj.OffcanvasUtils.toggle(self.drawerParams);
      }
      // Add a close listener so we can move focus back to the toggle button when the drawer closes
      $("#navDrawer").on("ojclose", function () { $('#drawerToggleButton').focus(); });

      // Header
      // Application Name used in Branding Area
      self.appName = ko.observable("Locum App");
      // User Info used in Global Navigation area
      self.userLogin = ko.observable("john.hancock@oracle.com");

      // Footer
      function footerLink(name, id, linkTarget) {
        this.name = name;
        this.linkId = id;
        this.linkTarget = linkTarget;
      }
      self.footerLinks = ko.observableArray([
        new footerLink('About Oracle', 'aboutOracle', 'http://www.oracle.com/us/corporate/index.html#menu-about'),
        new footerLink('Contact Us', 'contactUs', 'http://www.oracle.com/us/corporate/contact/index.html'),
        new footerLink('Legal Notices', 'legalNotices', 'http://www.oracle.com/us/legal/index.html'),
        new footerLink('Terms Of Use', 'termsOfUse', 'http://www.oracle.com/us/legal/terms/index.html'),
        new footerLink('Your Privacy Rights', 'yourPrivacyRights', 'http://www.oracle.com/us/legal/privacy/index.html')
      ]);

      self.navChange = function (item) {

        console.log("navChange", item, self.router.stateId());

        if (self.router.stateId() === "login") {
          navData([]);

          console.log("Here", self.LocumNotifications(), self.HeadNotifications());
        }

      };

      self.userType = ko.observable('');

      self.assignmentDoctorObject = ko.observable();


      self.Locum = ko.computed(function () {
        console.log("Locum computed");
        if (self.LocumNotifications() !== 0) {
          navData([{ name: 'Job History', notification: self.LocumNotifications(), id: 'dashboardLocum' }, { name: 'Landing Page', id: 'LandingPage' }, { name: 'Hospital Review', id: 'hospitalReview' }, { name: 'Logout', id: 'login' }]);

        }

      });

      self.Head = ko.computed(function () {

        console.log("Head computed");

        if (self.HeadNotifications() !== 0) {
          navData([{ name: 'List of Locums', notification: self.HeadNotifications(), id: 'dashboardHead' }, { name: 'Landing Page', id: 'LandingPage' }, { name: 'Dr Review', id: 'drReview' }, { name: 'Logout', id: 'login' }]);

        }

      });



      self.goTodashboardLocum = function () {

        self.router.go("/dashboardLocum");

      }

      self.goTodashboardHead = function () {

        self.router.go("/dashboardHead");

      }

      self.goTotimesheet = function () {

        self.router.go("/timesheet");

      }

      self.goTologin = function () {
        self.router.go("/login");
        self.userType('');

        //navData([]);

      }

      self.goToLandingPage = function () {
        self.router.go("/LandingPage");

      };

      self.goTodrAssignment = function () {
        self.router.go("/drAssignment");

      };

      self.goTodrReview = function () {
        self.router.go("/drReview");

      };

      self.goTosubmitReview = function () {
        self.router.go("/submitReview");

      };

      self.goTohospitalReview = function () {
        self.router.go("/hospitalReview");

      };

      self.goToshiftFeedback = function () {
        self.router.go("/shiftFeedback");

      };

      self.goTolocumSelect = function () {
        self.router.go("/locumSelect");

      };

      self.goToReVerifyIdentity = function() {
        self.router.go("/reVerifyIdentity");

      };

      self.goTolocumDrDetails = function () {
        self.router.go("/locumDr");

      };





    }


     genericMethods = function () {
    //  console.log("Check Appcontroller");
    //  console.log(this);

      var obj ={};

      let url = "http://51.140.13.206:31090/api/";

      obj.genericAjax = async function (obj,api,method) {

     //   console.log("In Generic Ajax");
     //   console.log(obj,api,method);

        var data = {};

        data.url = url+api;
        data.method= method;
        data.data = obj;

        const result = await $.ajax({
          type: "POST",
          url: "/genericAjax",
          data: JSON.stringify(data) || "",
          headers: { 'Content-Type': 'application/json' },
          success: function (data, status, jqXHR) {

            console.log("Success in genericAjax for " + api);
            console.log(data);

          },
          error: function (jqXHR, status) {
            alert("Error while genericQueryAjax "+api+" Please check the logs.");
            console.log(status);

          }
        });

       return result;

      }

      obj.genericDirectAjax = async function (obj,api,method) {

      //  console.log("In Generic Direct Ajax");
      //  console.log(obj,api,method);

        var data = {};

        data.url = url+api;
        data.method= method;
        data.data = obj;

        const result = await $.ajax({
          type: method,
          url: data.url,
          data: JSON.stringify(obj) || "",
          headers: { 'Content-Type': 'application/json' },
          success: function (data, status, jqXHR) {

            console.log("Success in genericAjax for " + api);
            console.log(data);
            Promise.resolve(data);

          },
          error: function (jqXHR, status) {
            alert("Error while genericQueryAjax "+api+" Please check the logs.");
            console.log(status);
            Promise.reject(jqXHR);

          }
        });

       return result;

      }

      obj.genericQueryAjax = async function (obj,api,method) {

     //   console.log("In Generic Ajax");
     //   console.log(obj,api,method);

        var data = {};

        data.url = url+"queries/"+api;
        data.method= method;
        data.data = obj;

        const result = await $.ajax({
          type: "POST",
          url: "/genericAjax",
          data: JSON.stringify(data) || "",
          headers: { 'Content-Type': 'application/json' },
          success: function (data, status, jqXHR) {

            console.log("Success in genericAjax for " + api);
            console.log(data);

          },
          error: function (jqXHR, status) {
            alert("Error while genericQueryAjax "+api+" Please check the logs.");
            console.log(status);

          }
        });


       return result;

      }

      obj.truuAjax = async function (obj,api,method) {
        var data = {};

        data.method= method;
        data.data = obj;

        var proof_name = obj.proof_name.split(' ').join('_');

        const result = await $.ajax({
          type: "GET",
          url: '/truuDoctorDetails?id=' + obj.id + "&proof_name=" + proof_name,
          headers: { 'Content-Type': 'application/json' },
          params: {id: obj.id},
          success: function (data, status, jqXHR) {
            console.log("Success in truuAjax for " + api);
            console.log(data);
          },
          error: function (jqXHR, status) {
            alert("Error while truuAjax "+api+" Please check the logs.");
            console.log(status);
          }
        });


       return result;
      }

      return obj;

    }();

    console.log("Generic Methods");
    console.log(genericMethods);

    return new ControllerViewModel();
  }
);
